<?php
header('Content-Type: application/json');

// DB Connection
$conn = new mysqli("127.0.0.1", "root", "root", "book", 3306);
if ($conn->connect_error) {
    die(json_encode(['error' => 'Database connection failed']));
}

// Fetch all bookings
$sql = "SELECT room, booking_date, start_time, end_time FROM booking";
$result = $conn->query($sql);

$bookings = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
}

$conn->close();

echo json_encode($bookings);
?>
