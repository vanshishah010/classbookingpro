<?php
ob_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to MySQL
$conn = new mysqli("127.0.0.1", "root", "root", "book", 3306);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read form data
$room = htmlspecialchars($_POST['room']);
$date = $_POST['date'];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];
$subject = htmlspecialchars($_POST['subject']);

// Insert into database
$sql = "INSERT INTO bookings (room, booking_date, start_time, end_time, subject) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $room, $date, $start_time, $end_time, $subject);

if ($stmt->execute()) {
    header("Location: dashboard.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
ob_end_flush();
?>
